package guiFirstAdmin;

import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.Scene;


/*******
 * <p> Title: ViewFirstAdmin Class - Enhanced Version</p>
 * 
 * <p> Description: The FirstAdmin Page View with modern CSS styling.
 * This class is used to require the very first user of the system to specify 
 * an Admin Username and Password when there is no database for the application.
 * 
 * Enhanced with modern CSS styling for improved user experience.</p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2025 </p>
 * 
 * @author Lynn Robert Carter (Enhanced)
 * 
 * @version 2.00		2026-02-05 Enhanced version with CSS styling
 *  
 */

public class ViewFirstAdmin {

	/*-********************************************************************************************

	Attributes

	 */

	// These are the application values required by the user interface
	
	private static double width = applicationMain.FoundationsMain.WINDOW_WIDTH;
	private static double height = applicationMain.FoundationsMain.WINDOW_HEIGHT;

	// These are the widget attributes for the GUI
	
	private static Label label_ApplicationTitle = new Label("Get Started");
	private static Label label_TitleLine1 = 
			new Label("You are the first user and the administrator.");
	
	private static Label label_TitleLine2 = 
			new Label("Set up Admin Username and Password.");
	
	protected static Label label_PasswordsDoNotMatch = new Label();
	protected static TextField text_AdminUsername = new TextField();
	protected static PasswordField text_AdminPassword1 = new PasswordField();
	protected static PasswordField text_AdminPassword2 = new PasswordField();
	private static Button button_AdminSetup = new Button("Setup Admin Account");

	// This alert is used should the user enter two passwords that do not match
	protected static Alert alertUsernamePasswordError = new Alert(AlertType.INFORMATION);

	// This button allow the user to abort creating the first admin account and terminate
	private static Button button_Quit = new Button("Quit");

	// These attributes are used to configure the page and populate it with this user's information
	protected static Stage theStage;	
	private static Pane theRootPane;
	private static Scene theFirstAdminScene = null;
	protected static Label label_AdminDoNotMatch = new Label();
	private static final int theRole = 1;		// Admin: 1; Role1: 2; Role2: 3
		
	
	/*-********************************************************************************************

	Constructor 

	 */
	
	/**********
	 * <p> Method: public displayFirstAdmin(Stage ps) </p>
	 * 
	 * <p> Description: This method is called when the application first starts. It create an
	 * an instance of the View class.  
	 * 
	 * @param ps specifies the JavaFX Stage to be used for this GUI and it's methods
	 */
	public static void displayFirstAdmin(Stage ps) {
		
		// Establish the references to the GUI.  There is no user yet.
		theStage = ps;			// Establish a reference to the JavaFX Stage
		
		// This page is only called once so there is no need to save the reference to it
		new ViewFirstAdmin();	// Create an instance of the class
		
		// Populate the dynamic aspects of the GUI with the data from the user and the current
		// state of the system.
		applicationMain.FoundationsMain.activeHomePage = theRole;	// 1: Admin; 2: Role1; 3 Roles2

		// Set the title for the window, display the page, and wait for the Admin to do something
		theStage.setTitle("CSE 360 Foundation Code: First User Account Setup");	
		theStage.setScene(theFirstAdminScene);
		theStage.show();
	}

	/**********
	 * <p> Method: private ViewFirstAdmin() </p>
	 * 
	 * <p> Description: This constructor creates and styles the GUI with modern CSS.</p>
	 * 
	 */
	private ViewFirstAdmin() {

		// Create a StackPane for centering and layering
		StackPane stackPane = new StackPane();
		stackPane.setStyle("-fx-background-color: linear-gradient(to bottom right, #f8f9fa, #e9ecef);");
		
		// Create a VBox for the form card
		VBox formCard = new VBox(20);
		formCard.setMaxWidth(500);
		formCard.setAlignment(Pos.CENTER);
		formCard.setPadding(new Insets(50, 60, 50, 60));
		formCard.setStyle(
			"-fx-background-color: white;" +
			"-fx-background-radius: 20;" +
			"-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.1), 30, 0, 0, 8);"
		);

		// Style the application title
		label_ApplicationTitle.setStyle(
			"-fx-font-size: 32px;" +
			"-fx-font-weight: bold;" +
			"-fx-text-fill: #2d3748;" +
			"-fx-font-family: 'Segoe UI Semibold', Arial;"
		);
		label_ApplicationTitle.setAlignment(Pos.CENTER);
		label_ApplicationTitle.setMaxWidth(Double.MAX_VALUE);

		// Style the subtitle
		label_TitleLine1.setStyle(
			"-fx-font-size: 18px;" +
			"-fx-font-weight: 600;" +
			"-fx-text-fill: #4a5568;"
		);
		label_TitleLine1.setAlignment(Pos.CENTER);
		label_TitleLine1.setMaxWidth(Double.MAX_VALUE);
		label_TitleLine1.setWrapText(true);

		// Style the instruction label
		label_TitleLine2.setStyle(
			"-fx-font-size: 14px;" +
			"-fx-text-fill: #718096;"
		);
		label_TitleLine2.setAlignment(Pos.CENTER);
		label_TitleLine2.setMaxWidth(Double.MAX_VALUE);
		label_TitleLine2.setWrapText(true);

		// Style text fields with modern design
		styleTextField(text_AdminUsername, "Username");
		styleTextField(text_AdminPassword1, "Password");
		styleTextField(text_AdminPassword2, "Confirm Password");

		// Add listeners
		text_AdminUsername.textProperty().addListener((_, _, _) 
				-> {ControllerFirstAdmin.setAdminUsername(); });
		text_AdminPassword1.textProperty().addListener((_, _, _)
				-> {ControllerFirstAdmin.setAdminPassword1(); });
		text_AdminPassword2.textProperty().addListener((_, _, _) 
				-> {ControllerFirstAdmin.setAdminPassword2(); });

		// Style the primary button
		button_AdminSetup.setStyle(
			"-fx-background-color: linear-gradient(to bottom, #48bb78, #38a169);" +
			"-fx-text-fill: white;" +
			"-fx-font-size: 16px;" +
			"-fx-font-weight: 600;" +
			"-fx-background-radius: 10;" +
			"-fx-padding: 14px 28px;" +
			"-fx-cursor: hand;" +
			"-fx-effect: dropshadow(gaussian, rgba(72, 187, 120, 0.3), 12, 0, 0, 4);"
		);
		button_AdminSetup.setMaxWidth(Double.MAX_VALUE);
		button_AdminSetup.setOnMouseEntered(e -> button_AdminSetup.setStyle(
			"-fx-background-color: linear-gradient(to bottom, #38a169, #2f855a);" +
			"-fx-text-fill: white;" +
			"-fx-font-size: 16px;" +
			"-fx-font-weight: 600;" +
			"-fx-background-radius: 10;" +
			"-fx-padding: 14px 28px;" +
			"-fx-cursor: hand;" +
			"-fx-effect: dropshadow(gaussian, rgba(72, 187, 120, 0.4), 15, 0, 0, 5);"
		));
		button_AdminSetup.setOnMouseExited(e -> button_AdminSetup.setStyle(
			"-fx-background-color: linear-gradient(to bottom, #48bb78, #38a169);" +
			"-fx-text-fill: white;" +
			"-fx-font-size: 16px;" +
			"-fx-font-weight: 600;" +
			"-fx-background-radius: 10;" +
			"-fx-padding: 14px 28px;" +
			"-fx-cursor: hand;" +
			"-fx-effect: dropshadow(gaussian, rgba(72, 187, 120, 0.3), 12, 0, 0, 4);"
		));
		button_AdminSetup.setOnAction((_) -> {
			ControllerFirstAdmin.doSetupAdmin(theStage,1); 
		});

		// Style error labels
		label_AdminDoNotMatch.setStyle(
			"-fx-text-fill: #e53e3e;" +
			"-fx-font-size: 13px;" +
			"-fx-font-weight: 500;"
		);
		label_AdminDoNotMatch.setMaxWidth(Double.MAX_VALUE);
		label_AdminDoNotMatch.setAlignment(Pos.CENTER);
		label_AdminDoNotMatch.setWrapText(true);
		
		label_PasswordsDoNotMatch.setStyle(
			"-fx-text-fill: #e53e3e;" +
			"-fx-font-size: 13px;" +
			"-fx-font-weight: 500;"
		);
		label_PasswordsDoNotMatch.setMaxWidth(Double.MAX_VALUE);
		label_PasswordsDoNotMatch.setAlignment(Pos.CENTER);
		label_PasswordsDoNotMatch.setWrapText(true);

		// Style the quit button
		button_Quit.setStyle(
			"-fx-background-color: transparent;" +
			"-fx-text-fill: #718096;" +
			"-fx-font-size: 14px;" +
			"-fx-font-weight: 500;" +
			"-fx-background-radius: 8;" +
			"-fx-border-color: #cbd5e0;" +
			"-fx-border-width: 2;" +
			"-fx-border-radius: 8;" +
			"-fx-padding: 10px 24px;" +
			"-fx-cursor: hand;"
		);
		button_Quit.setMaxWidth(Double.MAX_VALUE);
		button_Quit.setOnMouseEntered(e -> button_Quit.setStyle(
			"-fx-background-color: #f7fafc;" +
			"-fx-text-fill: #4a5568;" +
			"-fx-font-size: 14px;" +
			"-fx-font-weight: 500;" +
			"-fx-background-radius: 8;" +
			"-fx-border-color: #a0aec0;" +
			"-fx-border-width: 2;" +
			"-fx-border-radius: 8;" +
			"-fx-padding: 10px 24px;" +
			"-fx-cursor: hand;"
		));
		button_Quit.setOnMouseExited(e -> button_Quit.setStyle(
			"-fx-background-color: transparent;" +
			"-fx-text-fill: #718096;" +
			"-fx-font-size: 14px;" +
			"-fx-font-weight: 500;" +
			"-fx-background-radius: 8;" +
			"-fx-border-color: #cbd5e0;" +
			"-fx-border-width: 2;" +
			"-fx-border-radius: 8;" +
			"-fx-padding: 10px 24px;" +
			"-fx-cursor: hand;"
		));
		button_Quit.setOnAction((_) -> {ControllerFirstAdmin.performQuit(); });

		// Add spacing between sections
		VBox titleSection = new VBox(10);
		titleSection.setAlignment(Pos.CENTER);
		titleSection.getChildren().addAll(label_ApplicationTitle, label_TitleLine1, label_TitleLine2);
		
		VBox inputSection = new VBox(15);
		inputSection.setAlignment(Pos.CENTER);
		inputSection.getChildren().addAll(
			text_AdminUsername, 
			text_AdminPassword1, 
			text_AdminPassword2
		);
		
		VBox errorSection = new VBox(5);
		errorSection.setAlignment(Pos.CENTER);
		errorSection.getChildren().addAll(label_AdminDoNotMatch, label_PasswordsDoNotMatch);

		// Add all elements to the form card
		formCard.getChildren().addAll(
			titleSection,
			inputSection,
			errorSection,
			button_AdminSetup,
			button_Quit
		);

		// Center the form card in the StackPane
		stackPane.getChildren().add(formCard);
		StackPane.setAlignment(formCard, Pos.CENTER);

		// Create the scene
		theFirstAdminScene = new Scene(stackPane, width, height);
	}
	
	/**********
	 * Helper method to style text fields consistently
	 */
	private void styleTextField(TextField textField, String placeholder) {
		textField.setPromptText(placeholder);
		textField.setStyle(
			"-fx-background-color: white;" +
			"-fx-background-radius: 8;" +
			"-fx-border-color: #e2e8f0;" +
			"-fx-border-width: 2;" +
			"-fx-border-radius: 8;" +
			"-fx-padding: 12px 16px;" +
			"-fx-font-size: 15px;" +
			"-fx-text-fill: #2d3748;" +
			"-fx-prompt-text-fill: #a0aec0;"
		);
		textField.setMaxWidth(Double.MAX_VALUE);
		
		// Add focus effects
		textField.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
			if (isNowFocused) {
				textField.setStyle(
					"-fx-background-color: white;" +
					"-fx-background-radius: 8;" +
					"-fx-border-color: #48bb78;" +
					"-fx-border-width: 2;" +
					"-fx-border-radius: 8;" +
					"-fx-padding: 12px 16px;" +
					"-fx-font-size: 15px;" +
					"-fx-text-fill: #2d3748;" +
					"-fx-prompt-text-fill: #a0aec0;" +
					"-fx-effect: dropshadow(gaussian, rgba(72, 187, 120, 0.2), 8, 0, 0, 2);"
				);
			} else {
				textField.setStyle(
					"-fx-background-color: white;" +
					"-fx-background-radius: 8;" +
					"-fx-border-color: #e2e8f0;" +
					"-fx-border-width: 2;" +
					"-fx-border-radius: 8;" +
					"-fx-padding: 12px 16px;" +
					"-fx-font-size: 15px;" +
					"-fx-text-fill: #2d3748;" +
					"-fx-prompt-text-fill: #a0aec0;"
				);
			}
		});
	}
}